#Chatbot

Developed an AI-powered chatbot using Python and Flask, integrated with a custom dataset to generate intelligent responses. Implemented NLP preprocessing techniques for improved accuracy and built a responsive web interface with HTML, CSS, and JavaScript for seamless real-time conversations. The project highlights expertise in machine learning, natural language processing, and full-stack development, with potential applications in customer support, education, and personal assistance.
